/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.vanillaplus.init;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

import net.mcreator.vanillaplus.block.*;
import net.mcreator.vanillaplus.VanillaPlusMod;

import java.util.function.Function;

public class VanillaPlusModBlocks {
	public static Block FLIP_FLOP;
	public static Block FLIP_FLOP_ON;
	public static Block AND_GATE_OFF;
	public static Block AND_GATE_ON;
	public static Block OR_GATE_OFF;
	public static Block OR_GATE_ON;
	public static Block XOR_GATE_OFF;
	public static Block XOR_GATE_ON;

	public static void load() {
		FLIP_FLOP = register("flip_flop", FlipFlopBlock::new);
		FLIP_FLOP_ON = register("flip_flop_on", FlipFlopOnBlock::new);
		AND_GATE_OFF = register("and_gate_off", AndGateOffBlock::new);
		AND_GATE_ON = register("and_gate_on", AndGateOnBlock::new);
		OR_GATE_OFF = register("or_gate_off", OrGateOffBlock::new);
		OR_GATE_ON = register("or_gate_on", OrGateOnBlock::new);
		XOR_GATE_OFF = register("xor_gate_off", XorGateOffBlock::new);
		XOR_GATE_ON = register("xor_gate_on", XorGateOnBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> B register(String name, Function<BlockBehaviour.Properties, B> supplier) {
		return (B) Blocks.register(ResourceKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath(VanillaPlusMod.MODID, name)), (Function<BlockBehaviour.Properties, Block>) supplier, BlockBehaviour.Properties.of());
	}
}