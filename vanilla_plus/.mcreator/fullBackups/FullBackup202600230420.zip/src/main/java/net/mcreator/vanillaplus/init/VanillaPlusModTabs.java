/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.vanillaplus.init;

import net.minecraft.world.item.CreativeModeTabs;

import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;

public class VanillaPlusModTabs {
	public static void load() {
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.REDSTONE_BLOCKS).register(tabData -> {
			tabData.accept(VanillaPlusModBlocks.FLIP_FLOP.asItem());
			tabData.accept(VanillaPlusModBlocks.AND_GATE_OFF.asItem());
			tabData.accept(VanillaPlusModBlocks.OR_GATE_OFF.asItem());
			tabData.accept(VanillaPlusModBlocks.XOR_GATE_OFF.asItem());
		});
	}
}