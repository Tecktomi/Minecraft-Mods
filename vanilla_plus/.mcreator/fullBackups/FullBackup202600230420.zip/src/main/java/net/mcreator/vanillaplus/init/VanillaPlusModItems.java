/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.vanillaplus.init;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

import net.mcreator.vanillaplus.block.*;
import net.mcreator.vanillaplus.VanillaPlusMod;

import java.util.function.Function;

public class VanillaPlusModItems {
	public static Item FLIP_FLOP;
	public static Item FLIP_FLOP_ON;
	public static Item AND_GATE_OFF;
	public static Item AND_GATE_ON;
	public static Item OR_GATE_OFF;
	public static Item OR_GATE_ON;
	public static Item XOR_GATE_OFF;
	public static Item XOR_GATE_ON;

	public static void load() {
		FLIP_FLOP = register("flip_flop", FlipFlopBlock.Item::new);
		FLIP_FLOP_ON = block(VanillaPlusModBlocks.FLIP_FLOP_ON, "flip_flop_on");
		AND_GATE_OFF = register("and_gate_off", AndGateOffBlock.Item::new);
		AND_GATE_ON = block(VanillaPlusModBlocks.AND_GATE_ON, "and_gate_on");
		OR_GATE_OFF = register("or_gate_off", OrGateOffBlock.Item::new);
		OR_GATE_ON = register("or_gate_on", OrGateOnBlock.Item::new);
		XOR_GATE_OFF = register("xor_gate_off", XorGateOffBlock.Item::new);
		XOR_GATE_ON = register("xor_gate_on", XorGateOnBlock.Item::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> I register(String name, Function<Item.Properties, ? extends I> supplier) {
		return (I) Items.registerItem(ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(VanillaPlusMod.MODID, name)), (Function<Item.Properties, Item>) supplier);
	}

	private static Item block(Block block, String name) {
		return block(block, name, new Item.Properties());
	}

	private static Item block(Block block, String name, Item.Properties properties) {
		return Items.registerItem(ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(VanillaPlusMod.MODID, name)), prop -> new BlockItem(block, prop), properties);
	}
}